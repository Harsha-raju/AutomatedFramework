package com.example.automation.tests;

import com.example.automation.base.BaseTest;
import com.example.automation.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test
    public void validLoginTest() {
        LoginPage login = new LoginPage();
        login.open("https://example.com/login");
        login.enterUsername("testuser");
        login.enterPassword("password");
        login.submit();
        Assert.assertTrue(true, "Replace with real verification");
    }
}